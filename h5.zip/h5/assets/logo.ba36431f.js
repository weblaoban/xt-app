var o="/img/logo.png";export{o as _};
