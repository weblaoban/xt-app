var o="/img/close.png";export{o as _};
