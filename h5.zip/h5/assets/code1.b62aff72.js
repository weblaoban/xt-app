var a="/img/code.png",o="/img/code1.png";export{a as _,o as a};
